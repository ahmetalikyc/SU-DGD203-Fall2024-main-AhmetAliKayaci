namespace FirstGame.Engines
{
    public class DieselEngine : Engine
    {
    }
}