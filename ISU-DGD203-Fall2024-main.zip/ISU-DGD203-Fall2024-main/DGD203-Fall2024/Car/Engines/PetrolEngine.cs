namespace FirstGame.Engines
{
    public class PetrolEngine : Engine
    {
    }
}