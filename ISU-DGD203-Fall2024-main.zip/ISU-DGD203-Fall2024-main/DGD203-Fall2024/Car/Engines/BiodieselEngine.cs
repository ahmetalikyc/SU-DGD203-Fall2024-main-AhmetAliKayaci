namespace FirstGame.Engines;

public class BiodieselEngine : DieselEngine
{
    
}