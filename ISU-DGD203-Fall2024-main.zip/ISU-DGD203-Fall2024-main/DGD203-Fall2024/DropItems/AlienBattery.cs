namespace FirstGame
{
    public class AlienBattery : DropItem, IEngine, IWeapon
    {
        public void Start()
        {
        }

        public void Stop()
        {
        }

        public bool IsRunning()
        {
            return true;
        }

        public void Shoot()
        {
        }

        public void Reload()
        {
        }
    }
}