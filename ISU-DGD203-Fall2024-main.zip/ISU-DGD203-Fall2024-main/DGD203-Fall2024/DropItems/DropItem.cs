namespace FirstGame
{
    public abstract class DropItem
    {
    }
}