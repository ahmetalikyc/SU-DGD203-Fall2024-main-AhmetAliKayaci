namespace FirstGame
{
    public interface IWeapon
    {
        void Shoot();
        void Reload();
    }
}