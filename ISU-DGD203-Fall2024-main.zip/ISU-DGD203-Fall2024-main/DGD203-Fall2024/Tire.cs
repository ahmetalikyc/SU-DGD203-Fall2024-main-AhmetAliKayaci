namespace FirstGame;

public class Tire
{
    public string Type { get; private set; }

    public Tire(string type)
    {
        Type = type;
    }
}