namespace FirstGame;

public class Seat
{
    public bool Occupied { get; set; }

    public Seat()
    {
        Occupied = false;
    }
}