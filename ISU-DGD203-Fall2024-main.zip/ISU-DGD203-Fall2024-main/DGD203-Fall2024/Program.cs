﻿using System;

namespace FirstGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameController controller = new GameController();
            controller.StartGame();
        }
    }
}